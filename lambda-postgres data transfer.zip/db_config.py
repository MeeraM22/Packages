
host_name ="alexabankdb.ciujpbgex9s3.us-east-1.rds.amazonaws.com"
username = "alexabankdb"
password = "alexabankdb"
dbname = "onefacility_device_management"