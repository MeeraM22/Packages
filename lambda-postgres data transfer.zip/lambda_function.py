import json
import boto3
import db_config #Importing credentials from db_config file
import psycopg2 #Package to connect with pgAdmin
import logging # to get logs in cloudwatch
import os # to use environment variables set in configuration tab of aws lambda
import datetime

# to get logs in cloudwatch
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # print(context) # gives the information about cloudwatch logs like a metadat
    # variable initialized in environment variable
    years_of_cumulation = os.environ['years_of_cumulation']
    energy_sources=os.environ['energy_sources']
    print(energy_sources)
    #String to Integer Conversion
    years_of_cumulation=int(years_of_cumulation)
    print(years_of_cumulation)
    
    today = datetime.date.today() #to get current datetime
    currentYear=today.year #Stores current year value
    pastYear = currentYear-years_of_cumulation #Start range of cost trend
    print(pastYear)
    
    # to connect DB with this lambda
    connection = psycopg2.connect(user=db_config.username,
                password=db_config.password, host=db_config.host_name,
                database=db_config.dbname)
    
    # if the DB-Lambda connection is successful
    try:
        count=0
        databaseConnection = connection.cursor()
        
        #for loop to iterate between range of years
        for iterator in range(pastYear,currentYear+1):
            # variable year incorporated with the constant date, month and time
            formattedPastStartYear= str(iterator)+'-01-01 00:00:00';
            print(formattedPastStartYear);
            formattedPastEndYear= str(iterator)+'-12-31 23:59:00';
            print(formattedPastEndYear);
            #Energy sources
            device_source_list=energy_sources.split(",")
            
           
            
            #for loop to iterate among each source
            for source in device_source_list:
                count=count+1
                deviceDataQuery="select d.device_id , max(data) - min(data) as consumption from device_data dd join device d on dd.device_id = d.device_id join vendor_device_template vdt on d.vendor_device_template_id = vdt.vendor_device_template_id join device_template dt on dt.device_template_id = vdt.device_template_id join device_type on dt.device_type_id = device_type.device_type_id where system_data_point_id = 3 and device_type.name = '"+source+"' and dd.timestamp between '"+formattedPastStartYear+"' and '"+formattedPastEndYear+"' group by d.device_id"
                print(source)
                results = databaseConnection.execute(deviceDataQuery)
                
                #Array to store the consumption data retrieved from device_data table
                deviceDataArray=[]
                for deviceDataIterator in databaseConnection:
                    deviceDataArray.append(deviceDataIterator)
                    print(deviceDataArray)
                    
                #for loop to iterate the deviceDataArray 
                for data in deviceDataArray:
                    dataExtractor = iter(data)
                    device_id=next(dataExtractor)
                    consumption=next(dataExtractor)
                    print(device_id)
                    print(consumption)
                    #Inserting the data retrieved from device_data table into cumulative_cost_trend table
                    insert_query = "INSERT into cumulative_cost_trend(device_id, device_type, consumption, year) VALUES (%s,%s,%s,%s)"
                    valuesToBeInserted = (device_id,source,consumption,iterator)
                    results =  databaseConnection.execute(insert_query,valuesToBeInserted)
                    print('Insertion done...')
                
        print('Record Count'+ str(count))    
        databaseConnection.close()
        connection.commit()
       
    except Exception as e:
        print('Exception while insert:',e)

        
    