import json
import db_config
import psycopg2
import logging
import random
# from datetime import datetime
import datetime
# import time
from decimal import Decimal
 
# to get logs in cloudwatch
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)
 
# to connect DB with this lambda
connection = psycopg2.connect(user=db_config.username,
                password=db_config.password, host=db_config.host_name,
                database=db_config.dbname)
               
def lambda_handler(event, context):
    cursor = connection.cursor()
   
    insert_query = "insert into dummy (building, country)VALUES (%s,%s)"
    valuesToBeInserted = ('building3','country3')
    # results =  databaseConnection.execute(insert_query,valuesToBeInserted)
    
    cursor.execute(insert_query,valuesToBeInserted)
    count = cursor.rowcount
    print(count, "Record inserted successfully into dummy table")
    connection.commit()
   
    print('Insertion done...')
    cursor.close()
    
    
   